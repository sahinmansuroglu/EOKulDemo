﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YazdırmaDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StackPanel stackPanel;
        public MainWindow()
        {
            InitializeComponent();

            PageContent pageContent1 = new PageContent();
            fixedDocument1.Pages.Add(pageContent1);

            FixedPage fixedPage1 = new FixedPage();
            fixedPage1.Width = convertCmToPixel(21);
            fixedPage1.Height = convertCmToPixel(29.7);
            pageContent1.Child = fixedPage1;

            stackPanel = new StackPanel();
            stackPanel.Width = convertCmToPixel(19);
            stackPanel.Height = convertCmToPixel(27.7);
           // stackPanel.Background = Brushes.Red;

            FixedPage.SetLeft(stackPanel, convertCmToPixel(1));
            FixedPage.SetTop(stackPanel, convertCmToPixel(1));

            fixedPage1.Children.Add(stackPanel);


            stackPanel.Children.Add(Baslik("ABC Meslekli ve Teknik Anadolu Lisesi"));
            stackPanel.Children.Add(Baslik("Dönem Sonu Karnesi"));

            stackPanel.Children.Add(YataySiralamaliYiginPanel("Arda EKİN", "6584"));
            stackPanel.Children.Add(DersPuanDataGrid());
            stackPanel.Children.Add(OrtalamaBilgisiPaneli(85.25));

        }

        TextBlock Baslik(string metin)
        {
            TextBlock textBlock1 = new TextBlock();
            textBlock1.FontSize = 20;
            textBlock1.FontWeight = FontWeights.Bold;
            textBlock1.FontStretch = FontStretches.Medium;
            textBlock1.Text = metin;
            textBlock1.Margin = new Thickness(0, 0, 0, 5);
            textBlock1.HorizontalAlignment = HorizontalAlignment.Center;
            return textBlock1;
        }

        StackPanel YataySiralamaliYiginPanel(string adSoyad, string okulNo)
        {
            StackPanel stackPanel1 = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 20, 0, 10)
            };

            stackPanel1.Children.Add(new TextBlock()
            {
                Text = "Ad Soyad : ",
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(10, 0, 0, 0)

            });

            stackPanel1.Children.Add(new TextBlock()
            {
                Text = adSoyad,
                Margin = new Thickness(2, 0, 25, 0)
            });

            stackPanel1.Children.Add(new TextBlock()
            {
                Text = "Okul No : ",
                FontWeight = FontWeights.Bold,
            });
            stackPanel1.Children.Add(new TextBlock()
            {
                Text = okulNo,
            });

            stackPanel1.Children.Add(new TextBlock()
            {
                Text = "Tarih : ",
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(250, 0, 0, 0),
            });
            stackPanel1.Children.Add(new TextBlock()
            {
                Text = DateTime.Now.ToShortDateString(),
                Margin = new Thickness(2, 0, 25, 0)
            });

            stackPanel1.Children.Add(new TextBlock()
            {
                Text = "Saat : ",
                FontWeight = FontWeights.Bold,


            });
            stackPanel1.Children.Add(new TextBlock()
            {
                Text = DateTime.Now.ToShortTimeString(),

            });

            return stackPanel1;


        }

        DataGrid DersPuanDataGrid()
        {
            DataGrid dataGrid = new DataGrid();
            dataGrid.IsReadOnly = true;
            dataGrid.Foreground = Brushes.Black;
            dataGrid.AutoGenerateColumns = false;
            dataGrid.Background = Brushes.Transparent;
            dataGrid.Margin = new Thickness(0, 20, 0, 0);
            dataGrid.IsHitTestVisible = false;

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("DersAdi"),
                Header = "Ders Adı"
            });
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("DersSaati"),
                Header = "Ders Saati",
            });
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("Yazili1"),
                Header = "1. Yaz."
            });
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("Yazili2"),
                Header = "2. Yaz."
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("Performans1"),
                Header = "1. Perf."
            });
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("Performans2"),
                Header = "2. Perf."
            });
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("Ortalama"),
                Header = "Ortalama"
            });
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Binding = new Binding("Durum"),
                Header = "Durum"
            });

            return dataGrid;
        }

        StackPanel OrtalamaBilgisiPaneli(double? ortalama)
        {
            StackPanel stackPanel1 = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 10, 115, 0)
            };

            stackPanel1.Children.Add(new TextBlock()
            {
                Text = "Genel Ortalama : ",
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 0)

            });
            stackPanel1.Children.Add(new TextBlock()
            {
                Text = $"{ortalama:##.##}",
                Margin = new Thickness(2, 0, 25, 0)
            });

            return stackPanel1;

        }
         double convertCmToPixel(double xCm)
        {
            return (1 / 2.54) * 96 * xCm;

        }


    }
}
