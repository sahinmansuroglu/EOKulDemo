﻿using EOkulProjesi.Dogrulamalar;
using EOkulProjesi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FluentValidation.Results;
using ValidationResult = FluentValidation.Results.ValidationResult;
using EOkulProjesi.VtIslem;
using EOkulProjesi.FaydaliClasslar;

namespace EOkulProjesi
{
    /// <summary>
    /// OgrenciIslemleri.xaml etkileşim mantığı
    /// </summary>
    public partial class OgrenciIslemleri : UserControl
    {
        VtIslemOgrenci vtIslemOgrenci;
        public OgrenciIslemleri()
        {
            InitializeComponent();
            vtIslemOgrenci = new VtIslemOgrenci();
            dtGridOgrenci.ItemsSource = vtIslemOgrenci.SoneklenenOnOgrenciyiSec();
        }
        void temizle()
        {
            HataList.Items.Clear();
            txtAd.Clear();
            txtOgrenciId.Clear();
            txtOkulNo.Clear();
            txtSoyad.Clear();
        }

        private void btnTemizle_Click(object sender, RoutedEventArgs e)
        {
            temizle();
        }

        private void dtGridOgrenci_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Ogrenci secilenOgrenci = dtGridOgrenci.SelectedItem as Ogrenci;

            if (secilenOgrenci != null)
            {
                txtOgrenciId.Text = secilenOgrenci.Id.ToString();
                txtAd.Text = secilenOgrenci.Ad;
                txtSoyad.Text = secilenOgrenci.Soyad;
                txtOkulNo.Text = secilenOgrenci.OkulNo.ToString();
            }


        }

        private void btnEkle_Click(object sender, RoutedEventArgs e)
        {
            HataList.Items.Clear();

            Ogrenci eklenecekOgrenci = new Ogrenci()
            {
                Ad = txtAd.Text,
                Soyad = txtSoyad.Text,
                OkulNo = (Int32.TryParse(txtOkulNo.Text, out int okulNo) ? okulNo : (int?)null)
            };

            OgrenciDogrulama dogrulama = new OgrenciDogrulama();
            ValidationResult dogrulamaSonucu = dogrulama.Validate(eklenecekOgrenci);

            if (dogrulamaSonucu.IsValid == false)
            {
                foreach (ValidationFailure herBirHata in dogrulamaSonucu.Errors)
                {
                    HataList.Items.Add(herBirHata.ErrorMessage);
                }
            }
            else
            {
                //Aynı Okul Noya ait 2 öğrenci olamayacağı için kontrol gerekli
                var ogrenci = vtIslemOgrenci.OgrenciSecOkulNoyaGore(Int32.Parse(txtOkulNo.Text));
                if (ogrenci == null)
                {

                    int eklenenOgrenciSayisi = vtIslemOgrenci.YeniOgrenciEkle(eklenecekOgrenci);
                    if (eklenenOgrenciSayisi == 1)
                    {
                        MesajClass.BilgiMesajiGoster("Yeni Öğrenci Başarı ile Eklenmiştir", "Öğrenci ekleme");
                        dtGridOgrenci.ItemsSource = vtIslemOgrenci.SoneklenenOnOgrenciyiSec();
                        temizle();
                    }
                    else
                    {
                        MesajClass.hataMesajiGoster("Öğrenci ekleme sırasında hata oluştu", "Öğrenci ekleme Hatası");
                    }

                }
                else
                {
                    MesajClass.hataMesajiGoster($"{txtOkulNo.Text} okul nolu öğrenci daha önce eklenmiştir.", "Öğrenci ekleme Hatası");
                }

            }



        }

        private void btnGuncelle_Click(object sender, RoutedEventArgs e)
        {
            if (txtOgrenciId.Text != "")
            {
                HataList.Items.Clear();
                Ogrenci guncellenecekOgrenci = new Ogrenci()
                {
                    Id = Int32.Parse(txtOgrenciId.Text),
                    Ad = txtAd.Text,
                    Soyad = txtSoyad.Text,
                    OkulNo = (Int32.TryParse(txtOkulNo.Text, out int okulNo) ? okulNo : (int?)null)
                };

                OgrenciDogrulama dogrulama = new OgrenciDogrulama();
                ValidationResult dogrulamaSonucu = dogrulama.Validate(guncellenecekOgrenci);
                if (dogrulamaSonucu.IsValid == false)
                {
                    foreach (ValidationFailure herBirHata in dogrulamaSonucu.Errors)
                    {
                        HataList.Items.Add(herBirHata.ErrorMessage);
                    }
                }
                else
                {
                    //Aynı Okul Noya ait 2 öğrenci olamayacağı için kontrol gerekli
                    var ogrenci = vtIslemOgrenci.GuncellemeIcinOgrenciAra(Int32.Parse(txtOkulNo.Text), Int32.Parse(txtOgrenciId.Text));
                    if (ogrenci == null)
                    {
                        string guncellemeOnayıMesaji = $"{txtOkulNo.Text} : {txtAd.Text} {txtSoyad.Text} ad soyadlı öğrenciyi Güncellemek İstediğinize Emin misiniz?";
                        MessageBoxResult cevap = MesajClass.SoruMesajiGoster(guncellemeOnayıMesaji, "Öğrenci Güncelleme Onayı");
                        if (cevap == MessageBoxResult.Yes)
                        {

                            int guncellenenOgrenciSayisi = vtIslemOgrenci.OgrenciGuncelle(guncellenecekOgrenci);
                            if (guncellenenOgrenciSayisi == 1)
                            {
                                MesajClass.BilgiMesajiGoster("Öğrenci Güncelleme Başarılı", "Öğrenci Güncelleme");
                                dtGridOgrenci.ItemsSource = vtIslemOgrenci.SoneklenenOnOgrenciyiSec();
                                temizle();
                            }
                            else
                            {
                                MesajClass.hataMesajiGoster("Öğrenci Güncelleme sırasında hata oluştu", "Öğrenci ekleme Hatası");
                            }
                        }


                    }
                    else
                    {
                        MesajClass.hataMesajiGoster($"{txtOkulNo.Text} okul nolu öğrenci daha önce eklenmiştir.", "Öğrenci ekleme Hatası");

                    }
                }

            }
            else
            {
                MesajClass.hataMesajiGoster("Lütfen Güncelleştirilecek Öğrenciyi Seçiniz", "Öğrenci Güncelleme Hatası");
            }

        }

        private void btnAra_Click(object sender, RoutedEventArgs e)
        {
            int? OkulNo = (Int32.TryParse(txtOkulNo.Text, out int okulNo) ? okulNo : (int?)null);

            string Ad = txtAd.Text;
            string Soyad = txtSoyad.Text;
            if (OkulNo != null)
            {
                var ogrenciler = vtIslemOgrenci.OgrencileriSecOkulNoyaGore(okulNo);
                if (ogrenciler.Count == 0)
                {
                    MesajClass.BilgiMesajiGoster("Aranılan Öğrenci Bulunamadı", "Öğrenci Armama");
                }
                else
                {
                    dtGridOgrenci.ItemsSource = ogrenciler;
                }
            }
            else
            {
                if (Ad.Trim() != "" || Soyad.Trim() != "")
                {
                    var ogrenciler = vtIslemOgrenci.OgrencileriSecAdSoyadaGore(Ad, Soyad);
                    if (ogrenciler.Count == 0)
                    {
                        MesajClass.BilgiMesajiGoster("Aranılan Kriterlere uygun Öğrenci Bulunamadı", "Öğrenci Armama");
                    }
                    else
                    {
                        dtGridOgrenci.ItemsSource = ogrenciler;
                    }
                }


            }
        }

        private void btnSil_Click(object sender, RoutedEventArgs e)
        {
            if (txtOgrenciId.Text != "")
            {
                int ogrenciId = Int32.Parse(txtOgrenciId.Text);
                string silmeOnayıMesaji = $"{txtOkulNo.Text} : {txtAd.Text} {txtSoyad.Text} ad soyadlı öğrenciyi Silmek İstediğinize Emin misiniz?";
                MessageBoxResult cevap = MesajClass.SoruMesajiGoster(silmeOnayıMesaji, "Öğrenci Silme Onayı");
                if (cevap == MessageBoxResult.Yes)
                {
                    int silinenOgrenciSayisi = vtIslemOgrenci.OgrenciSil(ogrenciId);
                    if (silinenOgrenciSayisi == 1)
                    {
                        MesajClass.BilgiMesajiGoster("Öğrenci Silme Başarılı", "Öğrenci Silme");
                        dtGridOgrenci.ItemsSource = vtIslemOgrenci.SoneklenenOnOgrenciyiSec();
                        temizle();
                    }
                    else
                    {
                        MesajClass.hataMesajiGoster("Öğrenci Silme sırasında hata oluştu", "Öğrenci Silme Hatası");
                    }
                }

            }
            else
            {
                MesajClass.hataMesajiGoster("Lütfen Silinecek Öğrenciyi Seçiniz", "Öğrenci Silme Hatası");
            }
        }
    }

        
}
