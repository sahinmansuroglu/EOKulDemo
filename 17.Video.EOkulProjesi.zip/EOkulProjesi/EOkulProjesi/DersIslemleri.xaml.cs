﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EOkulProjesi.Models;
using EOkulProjesi.VtIslem;
using EOkulProjesi.Dogrulamalar;
using FluentValidation.Results;
using ValidationResult = FluentValidation.Results.ValidationResult;
using EOkulProjesi.FaydaliClasslar;
namespace EOkulProjesi
{
    /// <summary>
    /// DersIslemleri.xaml etkileşim mantığı
    /// </summary>
    public partial class DersIslemleri : UserControl
    {
        VtIslemDers vtIslemDers;
        public DersIslemleri()
        {
            InitializeComponent();
            vtIslemDers = new VtIslemDers();
            dtGridDers.ItemsSource = vtIslemDers.TumdersleriCek();
            dersSaatleriComboBoxiniDoldur();
        }

        void dersSaatleriComboBoxiniDoldur()
        {
            cbDersSaati.Items.Clear();
            for (int i = 1; i < 15; i++)
            {
                cbDersSaati.Items.Add(i.ToString());
            }
            cbDersSaati.SelectedIndex = 1;

        }
        private void Temizle()
        {
            txtDersId.Clear();
            txtDersAdi.Clear();
            txtDersKodu.Clear();
            HataList.Items.Clear();
        }

        private void btnEkle_Click(object sender, RoutedEventArgs e)
        {
            HataList.Items.Clear();
            Ders eklenecekDers = new Ders()
            {
                DersAdi = txtDersAdi.Text,
                DersKodu=txtDersKodu.Text,
                DersSaati=Int32.Parse(cbDersSaati.Text)

            };

            DersDogrulama dogrulama = new DersDogrulama();
            ValidationResult validationResult= dogrulama.Validate(eklenecekDers);

            if (validationResult.IsValid == false)
            {
                foreach (var herbirHata in validationResult.Errors)
                {
                    HataList.Items.Add(herbirHata.ErrorMessage);
                }
            }
            else
            {
                //Aynı Ders Koduna ait 2 Ders olamayacağı için kontrol gerekli
                var bulunanders = vtIslemDers.DersSecDersKodunaGore(txtDersKodu.Text);
                if (bulunanders == null)
                {
                    //Ekleme Yapılabilir
                    int eklenenDersSayisi = vtIslemDers.YeniDersEkle(eklenecekDers);
                    if (eklenenDersSayisi == 1)
                    {
                        MesajClass.BilgiMesajiGoster("Yeni Ders Başarı ile Eklenmiştir", "Ders ekleme");
                        dtGridDers.ItemsSource = vtIslemDers.TumdersleriCek();

                        Temizle();
                    }
                    else
                    {
                        MesajClass.hataMesajiGoster("Ders ekleme sırasında hata oluştu", "Ders ekleme Hatası");

                    }


                    }
                else
                {
                    MesajClass.hataMesajiGoster($"{txtDersKodu.Text} kodlu ders daha önce eklenmiştir.", "Ders ekleme Hatası");

                }

              

            }
        }

        private void btnTemizle_Click(object sender, RoutedEventArgs e)
        {
            Temizle();
        }

        private void dtGridDers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Ders secilenDers = dtGridDers.SelectedItem as Ders;
            if (secilenDers != null)
            {
                txtDersAdi.Text = secilenDers.DersAdi.ToString();
                txtDersId.Text = secilenDers.Id.ToString();
                txtDersKodu.Text = secilenDers.DersKodu.ToString();
                cbDersSaati.SelectedIndex = secilenDers.DersSaati - 1;
            }
         }

        private void btnSil_Click(object sender, RoutedEventArgs e)
        {
            if (txtDersId.Text != "")
            {
                int dersId = Int32.Parse(txtDersId.Text);
                string silmeOnayıMesaji = $"{txtDersKodu.Text} : {txtDersAdi.Text}  dersini Silmek İstediğinize Emin misiniz?";
                MessageBoxResult cevap = MesajClass.SoruMesajiGoster(silmeOnayıMesaji, "Ders Silme Onayı");
                if (cevap == MessageBoxResult.Yes)
                {
                    int silinenDersSayisi = vtIslemDers.DersSil(dersId);
                    if (silinenDersSayisi == 1)
                    {
                        MesajClass.BilgiMesajiGoster("Ders Silme Başarılı", "Ders Silme");
                        dtGridDers.ItemsSource = vtIslemDers.SonEklenenOnDersiCek();
                        Temizle();
                    }
                    else
                    {
                        MesajClass.hataMesajiGoster("Ders Silme sırasında hata oluştu", "Ders Silme Hatası");
                    }
                }

            }
            else
            {
                MesajClass.hataMesajiGoster("Lütfen Silinecek Dersi Seçiniz", "Ders Silme Hatası");
            }
      }

        private void btnAra_Click(object sender, RoutedEventArgs e)
        {
            if (txtDersAdi.Text.Trim() != string.Empty || txtDersKodu.Text.Trim() != string.Empty)
            {
                //Arama İşlemini Burada Başlat
                var dersler = vtIslemDers.DersAdiVeKodunaGoreArama(txtDersAdi.Text, txtDersKodu.Text);
                if (dersler.Count == 0)
                {
                    MesajClass.BilgiMesajiGoster("Kriterlere uygun Ders Bulunamadı", "Ders Arama");
                }
                else
                {
                    dtGridDers.ItemsSource = dersler;
                }

            }
            else
            {
                MesajClass.BilgiMesajiGoster("Lütfen Aramak istediğiniz Ders adını veya kodunu giriniz", "Ders Arama");

            }
        }

        private void btnGuncelle_Click(object sender, RoutedEventArgs e)
        {
            if (txtDersId.Text != "")
            {
                HataList.Items.Clear();
                Ders guncellenecekDers = new Ders()
                {
                    Id = Int32.Parse(txtDersId.Text),
                    DersAdi = txtDersAdi.Text,
                    DersKodu = txtDersKodu.Text,
                    DersSaati = Int32.Parse(cbDersSaati.Text)
                };
                DersDogrulama dogrulama = new DersDogrulama();
                ValidationResult dogrulamaSonucu = dogrulama.Validate(guncellenecekDers);
                if (dogrulamaSonucu.IsValid == false)
                {
                    foreach (ValidationFailure herBirHata in dogrulamaSonucu.Errors)
                    {
                        HataList.Items.Add(herBirHata.ErrorMessage);
                    }
                }
                else
                {
                    //Aynı Okul Noya ait 2 Ders olamayacağı için kontrol gerekli
                    var ders = vtIslemDers.GuncellemeIcinDersAra(txtDersKodu.Text, Int32.Parse(txtDersId.Text));
                    if (ders == null)
                    {
                        //Güncelleme Yapılabilir
                        string GuncellemeOnayıMesaji = $"{txtDersKodu.Text} : {txtDersAdi.Text}  dersini Güncellemek İstediğinize Emin misiniz?";
                        MessageBoxResult cevap = MesajClass.SoruMesajiGoster(GuncellemeOnayıMesaji, "Ders Güncelleme Onayı");
                        if (cevap == MessageBoxResult.Yes)
                        {
                            int guncellenenDersSayisi = vtIslemDers.DersGuncelle(guncellenecekDers);
                            if (guncellenenDersSayisi == 1)
                            {
                                MesajClass.BilgiMesajiGoster("Ders Güncelleme Başarılı", "Öğrenci Güncelleme");
                                dtGridDers.ItemsSource = vtIslemDers.SonEklenenOnDersiCek();
                                Temizle();
                            }
                            else
                            {
                                MesajClass.hataMesajiGoster("Ders Güncelleme sırasında hata oluştu", "Ders Güncelleme Hatası");
                            }


                        }

                    }
                    else
                    {
                        MesajClass.hataMesajiGoster($"{txtDersKodu.Text} kodlu Ders daha önce eklenmiştir.", "Ders güncellemeHatası");
                    }


                    }
            }
            else
            {

                MesajClass.hataMesajiGoster("Lütfen Güncelleştirilecek Dersi Seçiniz", "Ders Güncelleme Hatası");
            }

         }
    }
}
