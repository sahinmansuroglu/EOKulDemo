﻿using EOkulProjesi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EOkulProjesi.VtIslem;
using EOkulProjesi.Dogrulamalar;
using FluentValidation.Results;
using ValidationResult = FluentValidation.Results.ValidationResult;
using EOkulProjesi.FaydaliClasslar;

namespace EOkulProjesi
{
    /// <summary>
    /// NotIslemleri.xaml etkileşim mantığı
    /// </summary>
    public partial class NotIslemleri : UserControl
    {
        VtIslemDers vtIslemDers;
        VtIslemOgrenciPuan vtIslemOgrenciPuan;
        VtIslemOgrenci vtIslemOgrenci;


        OgrenciSecmePenceresi ogrenciSecmePenceresi;
        OzIzlemePenceresi ozIzlemePenceresi;

        Ogrenci? secilenOgrenci;
        OgrenciPuan seciliOgrenciPuan;


        public NotIslemleri()
        {
            InitializeComponent();

            vtIslemDers = new VtIslemDers();
            vtIslemOgrenciPuan = new VtIslemOgrenciPuan();
            vtIslemOgrenci = new VtIslemOgrenci();

            cbDers.ItemsSource = vtIslemDers.TumdersleriCek();
            cbDers.SelectedValuePath = "Id";
            cbDers.DisplayMemberPath = "DersBaslik";

            ogrenciSecmePenceresi = new OgrenciSecmePenceresi();
            ogrenciSecmePenceresi.lstOgrenciler.SelectionChanged += LstOgrenciler_SelectionChanged;

            ozIzlemePenceresi = new OzIzlemePenceresi();

            dtGridPuan.ItemsSource = vtIslemOgrenciPuan.TumPuanlariCek();
        }

        private void LstOgrenciler_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ogrenciSecmePenceresi.lstOgrenciler.SelectedItem!=null)
            {
                secilenOgrenci = ogrenciSecmePenceresi.lstOgrenciler.SelectedItem as Ogrenci;
                txtSecilenOgrenci.Text = secilenOgrenci.ToString();
            }
        }

        private void btnOgrenciSec_Click(object sender, RoutedEventArgs e)
        {
            ogrenciSecmePenceresi.ShowDialog();
        }

        private void btnYazdir_Click(object sender, RoutedEventArgs e)
        {
            ozIzlemePenceresi.ShowDialog();
        }

        private void dtGridPuan_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           seciliOgrenciPuan= dtGridPuan.SelectedItem as OgrenciPuan;
            if (seciliOgrenciPuan!=null)
            {
                txtYazili1.Text = seciliOgrenciPuan.Yazili1.ToString();
                txtYazili2.Text = seciliOgrenciPuan.Yazili2.ToString();
                txtPerformans1.Text = seciliOgrenciPuan.Performans1.ToString();
                txtPerformans2.Text = seciliOgrenciPuan.Performans2.ToString();

                txtOrtalama.Text = seciliOgrenciPuan.Ortalama.ToString();
                txtDurum.Text = seciliOgrenciPuan.Durum.ToString();

                secilenOgrenci = vtIslemOgrenci.OgrenciSecIdyeGore(seciliOgrenciPuan.OgrenciId);
                txtSecilenOgrenci.Text = secilenOgrenci.ToString();

                cbDers.SelectedValue = seciliOgrenciPuan.DersId;
                txtOgrenciPuanId.Text = seciliOgrenciPuan.Id.ToString();
            }



        }

        private void btnTemizle_Click(object sender, RoutedEventArgs e)
        {
            temizle();
        }

        void temizle()
        {
            secilenOgrenci = null;
            txtSecilenOgrenci.Clear();
            txtYazili1.Clear();
            txtYazili2.Clear();
            txtPerformans1.Clear();
            txtPerformans2.Clear();
            txtOrtalama.Clear();
            txtDurum.Clear();
            cbDers.SelectedItem = null;
            HataList.Items.Clear();
            seciliOgrenciPuan = null;
            txtOgrenciPuanId.Clear();

        }

        private void btnEkle_Click(object sender, RoutedEventArgs e)
        {
            HataList.Items.Clear();
            if (secilenOgrenci != null & cbDers.SelectedItem != null)
            {
                int ogrenciId = secilenOgrenci.Id;
                int dersId = (cbDers.SelectedItem as Ders).Id;

                OgrenciPuan eklenecekOgrenciPuan = new OgrenciPuan()
                {
                    DersId = dersId,
                    OgrenciId = ogrenciId,
                    Yazili1 = (Int32.TryParse(txtYazili1.Text, out int yazili1) ? yazili1 : (int?)null),
                    Yazili2 = (Int32.TryParse(txtYazili1.Text, out int yazili2) ? yazili1 : (int?)null),
                    Performans1 = (Int32.TryParse(txtPerformans1.Text, out int performans1) ? performans1 : (int?)null),
                    Performans2 = (Int32.TryParse(txtPerformans2.Text, out int performans2) ? performans2 : (int?)null)
                };

                eklenecekOgrenciPuan.OrtalamaVeDurumHesapla();

                OgrenciPuanDogrulama dogrulama = new OgrenciPuanDogrulama();
                ValidationResult dogrulamaSonucu = dogrulama.Validate(eklenecekOgrenciPuan);
                if (dogrulamaSonucu.IsValid == false)
                {
                    foreach (ValidationFailure herBirHata in dogrulamaSonucu.Errors)
                    {
                        HataList.Items.Add(herBirHata.ErrorMessage);
                    }
                }
                else
                {
                    //Bir Öğrencinin bir derse ait sadece bir tane puanı olmalı
                    OgrenciPuan ogrenciPuan = vtIslemOgrenciPuan.PuanBulOgrenciveDerseGore(ogrenciId, dersId);
                    if (ogrenciPuan == null)
                    {
                        int eklenenOgrenciPuanSayisi = vtIslemOgrenciPuan.YeniOgrenciPuanEkle(eklenecekOgrenciPuan);
                        if (eklenenOgrenciPuanSayisi == 1)
                        {
                            MesajClass.BilgiMesajiGoster("Yeni Öğrenci Puanı Başarı ile Eklenmiştir", "Öğrenci Puanı ekleme");
                            dtGridPuan.ItemsSource = vtIslemOgrenciPuan.TumPuanlariCek(); ;
                            temizle();
                        }
                        else
                        {
                            MesajClass.hataMesajiGoster("Öğrenci Puan ekleme sırasında hata oluştu", "Öğrenci Puan ekleme Hatası");
                        }
                    }
                    else
                    {
                        MesajClass.hataMesajiGoster("Bir Öğrencinin Bir derse ait sadece bir notu bulunabilir", "Puan ekleme Hatası");
                    }
                }

            }
            else
            {
                HataList.Items.Add("Lütfen Öğrenci ve Dersi Seçiniz");
            }

        }

        private void btnGuncelle_Click(object sender, RoutedEventArgs e)
        {
            HataList.Items.Clear();
            if (txtOgrenciPuanId.Text != "")
            {
                OgrenciPuan guncellenecekOgrenciPuan = new OgrenciPuan()
                {
                    Id = Int32.Parse(txtOgrenciPuanId.Text),
                    Yazili1 = (Int32.TryParse(txtYazili1.Text, out int yazili1) ? yazili1 : (int?)null),
                    Yazili2 = (Int32.TryParse(txtYazili2.Text, out int yazili2) ? yazili2 : (int?)null),
                    Performans1 = (Int32.TryParse(txtPerformans1.Text, out int performans1) ? performans1 : (int?)null),
                    Performans2 = (Int32.TryParse(txtPerformans2.Text, out int performans2) ? performans2 : (int?)null)
                };
                guncellenecekOgrenciPuan.OrtalamaVeDurumHesapla();

                OgrenciPuanDogrulama dogrulama = new OgrenciPuanDogrulama();
                ValidationResult dogrulamaSonucu = dogrulama.Validate(guncellenecekOgrenciPuan);

                if (dogrulamaSonucu.IsValid == false)
                {
                    foreach (ValidationFailure herBirHata in dogrulamaSonucu.Errors)
                    {
                        HataList.Items.Add(herBirHata.ErrorMessage);
                    }
                }
                else
                {
                    string guncellemeOnayıMesaji = $"{txtSecilenOgrenci.Text}  ad soyadlı öğrencinin puanını güncellemek İstediğinize Emin misiniz?";
                    MessageBoxResult cevap = MesajClass.SoruMesajiGoster(guncellemeOnayıMesaji, "Öğrenci Puan Güncelleme Onayı");
                    if (cevap == MessageBoxResult.Yes)
                    {
                        int guncellenenOgrenciPuanSayisi = vtIslemOgrenciPuan.OgrenciPuanGuncelle(guncellenecekOgrenciPuan);
                        if (guncellenenOgrenciPuanSayisi == 1)
                        {
                            MesajClass.BilgiMesajiGoster("Öğrenci Puanı Güncelleme Başarı ile Eklenmiştir", "Öğrenci Puanı Güncelleme");
                            dtGridPuan.ItemsSource = vtIslemOgrenciPuan.TumPuanlariCek(); ;
                            temizle();
                        }
                        else
                        {
                            MesajClass.hataMesajiGoster("Öğrenci Puanı Güncelleme sırasında hata oluştu", "Öğrenci Puan Güncelleme Hatası");
                        }
                    }
                }
            }
            else
            {
                MesajClass.hataMesajiGoster("Lütfen Güncelleştirilecek Öğrenci Puanını Seçiniz", "Öğrenci Puanı Güncelleme Hatası");
            }

        }

        private void btnSil_Click(object sender, RoutedEventArgs e)
        {
            HataList.Items.Clear();
            if (txtOgrenciPuanId.Text != "")
            {
                string silmeOnayıMesaji = $"{txtSecilenOgrenci.Text}  ad soyadlı öğrencinin puanını silmek İstediğinizden Emin misiniz?";
                MessageBoxResult cevap = MesajClass.SoruMesajiGoster(silmeOnayıMesaji, "Öğrenci Puan Silme Onayı");
                if (cevap == MessageBoxResult.Yes)
                {
                    int silinenOgrenciPuanSayisi = vtIslemOgrenciPuan.OgrenciPuanSil(Int32.Parse(txtOgrenciPuanId.Text));
                    if (silinenOgrenciPuanSayisi == 1)
                    {
                        MesajClass.BilgiMesajiGoster("Öğrenci Puanı Silme Başarı ile Eklenmiştir", "Öğrenci Puanı Güncelleme");
                        dtGridPuan.ItemsSource = vtIslemOgrenciPuan.TumPuanlariCek(); ;
                        temizle();
                    }
                    else
                    {
                        MesajClass.hataMesajiGoster("Öğrenci Puanı silme sırasında hata oluştu", "Öğrenci Puan Silme Hatası");
                    }
                }
            }
            else
            {
                MesajClass.hataMesajiGoster("Lütfen Silinecek Öğrenci Puanını Seçiniz", "Öğrenci Puanı Silme Hatası");
            }

        }

        private void btnAraOgrenci_Click(object sender, RoutedEventArgs e)
        {
            if (secilenOgrenci != null)
            {
                var ogrenciPuanlari = vtIslemOgrenciPuan.OgrenciPuanAraOgrenciIdYeGore(secilenOgrenci.Id);
                if (ogrenciPuanlari.Count == 0)
                {
                    MesajClass.BilgiMesajiGoster("Seçilen Öğrenciye ait puan Bulunamadı", "Öğrenci Puan Arama");
                }
                else
                {
                    dtGridPuan.ItemsSource = ogrenciPuanlari;
                }
            }
            else
            {
                MesajClass.BilgiMesajiGoster("Lütfen Puanlarını Görüntülemek İstediğiniz Öğrenciyi Seçiniz", "Öğrenci Seçme");
            }


        }

        private void btnAraDers_Click(object sender, RoutedEventArgs e)
        {
            if (cbDers.SelectedItem != null)
            {
                int dersId = Int32.Parse(cbDers.SelectedValue.ToString());
                var ogrenciPuanlari = vtIslemOgrenciPuan.OgrenciPuanAraDersIdYeGore(dersId);
                if (ogrenciPuanlari.Count == 0)
                {
                    MesajClass.BilgiMesajiGoster("Seçilen Derse ait puan Bulunamadı", "Derse ait Puan Arama");
                }
                else
                {
                    dtGridPuan.ItemsSource = ogrenciPuanlari;
                }
            }
            else
            {
                MesajClass.BilgiMesajiGoster("Lütfen Puanlarını Görüntülemek İstediğiniz Dersi Seçiniz", "Ders Seçme");
            }
        }
    }
}
