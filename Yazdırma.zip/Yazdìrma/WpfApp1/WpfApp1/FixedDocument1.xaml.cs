﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for FixedDocument1.xaml
    /// </summary>
    public partial class FixedDocument1 : Window
    {
        ObservableCollection<Ogrenci> ogrenciler;
        public FixedDocument1()
        {
            InitializeComponent();
            ogrencileriDoldur();
            PageContent pageContent1 = new PageContent();
            FixedPage fixedPage1 = new FixedPage();
            StackPanel stackPanel = new StackPanel();

            fixedPage1.Width = convertCmToPixel(21);
            fixedPage1.Height = convertCmToPixel(29.7);

            stackPanel.Background= new SolidColorBrush(Colors.Red);
            stackPanel.Width= convertCmToPixel(19);
            stackPanel.Height = convertCmToPixel(27.7);
            fixedPage1.Children.Add(stackPanel);
        
            TextBlock baslik=new TextBlock();
            baslik.FontSize = convertCmToPixel(1);
            baslik.Text = "Mezitli MTAL Dönem Sonu Karnesi";
            stackPanel.Children.Add(baslik);
            baslik.HorizontalAlignment = HorizontalAlignment.Center;
            DataGrid dataGrid=new DataGrid();
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                // bind to a dictionary property
                Binding = new Binding("Ad"),
                Header = "Öğrenci Adı"
            });
            dataGrid.Columns.Add(new DataGridTextColumn
            {
                // bind to a dictionary property
                Binding = new Binding("Soyad"),
                Header = "Öğrenci Soyadı"
            });

            dataGrid.ItemsSource = ogrenciler;
            FixedPage.SetLeft(stackPanel, convertCmToPixel(1));
            FixedPage.SetTop(stackPanel, convertCmToPixel(1));

         
            Label textBlock1=new Label();
            textBlock1.Foreground= new SolidColorBrush(Colors.DarkGray);
            textBlock1.Content = "Merhaba Dünya";
            textBlock1.FontSize = 45;
            
            //FixedPage.SetLeft(textBlock1, 96*6);
            stackPanel.Children.Add(textBlock1);
            stackPanel.Children.Add(dataGrid);
            pageContent1.Child = fixedPage1;
            fixDoc.Pages.Add(pageContent1);


        }

        void ogrencileriDoldur()
        {
            ogrenciler = new ObservableCollection<Ogrenci>();
            ogrenciler.Add(new Ogrenci
            {
                Ad = "Ayhan",
                Soyad = "ERKMEN",
                Yazili1 = 66,
                Yazili2 = 55

            });
            ogrenciler.Add(new Ogrenci
            {
                Ad = "Esra",
                Soyad = "EN",
                Yazili1 = 58,
                Yazili2 = 90

            });
            ogrenciler.Add(new Ogrenci
            {
                Ad = "Alin",
                Soyad = "EREN",
                Yazili1 = 66,
                Yazili2 = 10

            });
        }
        double convertCmToPixel(double cm)
        {
            return (1 / 2.54) * 96 * cm;     
        
        }
    }

   
}
