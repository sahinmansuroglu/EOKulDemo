﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    class Ogrenci : INotifyPropertyChanged
    {
        private string ad;
        public string Ad
        {
            get
            {

                return ad;
            }
            set
            {
                ad = value;
                OnPropertyChanged("Ad");
            }

        }
        private string soyad;
        public string Soyad
        {
            get
            {

                return soyad;
            }
            set
            {
                soyad = value;
                OnPropertyChanged("Soyad");
            }

        }

        private int yazili1;

        public int Yazili1
        {
            get { return yazili1; }
            set
            {
                yazili1 = value;
                OnPropertyChanged("Ortalama");
                OnPropertyChanged("Durum");
            }
        }

        private int yazili2;

        public int Yazili2
        {
            get { return yazili2; }
            set
            {
                yazili2 = value;
                OnPropertyChanged("Ortalama");
                OnPropertyChanged("Durum");

            }
        }

        public double Ortalama
        {
            get
            {
                return (Yazili1 + Yazili2) / 2.0;
            }

        }
        public string Durum
        {
            get
            {
                return Ortalama < 50 ? "Kaldınız" : "Geçtiniz";
            }

        }
        protected internal virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
