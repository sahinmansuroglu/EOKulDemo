﻿using EOkulProjesi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOkulProjesi.VtIslem
{
    internal class Base
    {
        protected string ConnectionString = "host=localhost;port=3306;user id=root;password=123456;database=eokul;";

        
    }
}
