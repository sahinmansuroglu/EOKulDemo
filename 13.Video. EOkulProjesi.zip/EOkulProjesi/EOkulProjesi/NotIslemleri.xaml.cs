﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EOkulProjesi
{
    /// <summary>
    /// NotIslemleri.xaml etkileşim mantığı
    /// </summary>
    public partial class NotIslemleri : UserControl
    {
        OgrenciSecmePenceresi ogrenciSecmePenceresi;
        OzIzlemePenceresi ozIzlemePenceresi;
        public NotIslemleri()
        {
            InitializeComponent();
            ogrenciSecmePenceresi = new OgrenciSecmePenceresi();
            ozIzlemePenceresi = new OzIzlemePenceresi();
        }

        private void btnOgrenciSec_Click(object sender, RoutedEventArgs e)
        {
            ogrenciSecmePenceresi.ShowDialog();
        }

        private void btnYazdir_Click(object sender, RoutedEventArgs e)
        {
            ozIzlemePenceresi.ShowDialog();
        }
    }
}
